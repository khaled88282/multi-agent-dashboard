const router=require('express').Router();const path=require('path');const db=require('../db/models');const sm=require('../orchestrator/sessionManager');const wt=require('../orchestrator/worktreeManager');
router.get('/',(req,res)=>res.json(db.listSessions()));
router.post('/',async(req,res,next)=>{try{const {name,repositoryPath}=req.body||{};const session=await sm.createSession({name,repositoryPath:repositoryPath||process.env.DEFAULT_REPOSITORY_PATH});res.status(201).json(session);}catch(e){next(e);}});
router.get('/:id',(req,res)=>{const s=db.getSession(req.params.id);if(!s)return res.status(404).json({error:'Session not found'});res.json(s);});
router.post('/:id/stop',(req,res)=>{const s=db.getSession(req.params.id);if(!s)return res.status(404).json({error:'Session not found'});sm.stopSession(req.app.get('io'),s);res.json(db.getSession(s.id));});
router.delete('/:id',async(req,res,next)=>{try{const s=db.getSession(req.params.id);if(!s)return res.status(404).json({error:'Session not found'});sm.stopSession(req.app.get('io'),s);for(const t of s.tasks)await wt.removeWorktree(s.repository_path,t.worktree_path);db.deleteSession(s.id);res.status(204).end();}catch(e){next(e);}});
module.exports=router;
