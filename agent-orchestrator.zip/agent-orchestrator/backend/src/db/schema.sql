PRAGMA journal_mode = WAL;
CREATE TABLE IF NOT EXISTS sessions (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, repository_path TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'idle', created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS tasks (
 id TEXT PRIMARY KEY, session_id TEXT NOT NULL, prompt TEXT NOT NULL, agent TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'queued', worktree_path TEXT, branch_name TEXT,
 started_at TEXT, finished_at TEXT, exit_code INTEGER, error TEXT,
 FOREIGN KEY(session_id) REFERENCES sessions(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS logs (
 id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT NOT NULL, stream TEXT NOT NULL,
 message TEXT NOT NULL, created_at TEXT NOT NULL,
 FOREIGN KEY(task_id) REFERENCES tasks(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_tasks_session ON tasks(session_id);
CREATE INDEX IF NOT EXISTS idx_logs_task ON logs(task_id, id);
