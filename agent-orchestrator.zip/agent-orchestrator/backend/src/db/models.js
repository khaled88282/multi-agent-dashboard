const Database = require('better-sqlite3');
const fs = require('fs'); const path = require('path');
let db;
const now = () => new Date().toISOString();
function initDb(file) { fs.mkdirSync(path.dirname(file), {recursive:true}); db = new Database(file); db.pragma('foreign_keys = ON'); db.exec(fs.readFileSync(path.join(__dirname,'schema.sql'),'utf8')); return db; }
function getDb(){ if(!db) throw new Error('Database is not initialized'); return db; }
function createSession(s){ getDb().prepare('INSERT INTO sessions VALUES (@id,@name,@repository_path,@status,@created_at,@updated_at)').run({...s,status:'idle',created_at:now(),updated_at:now()}); return getSession(s.id); }
function listSessions(){ return getDb().prepare('SELECT * FROM sessions ORDER BY created_at DESC').all().map(hydrate); }
function getSession(id){ const s=getDb().prepare('SELECT * FROM sessions WHERE id=?').get(id); return s&&hydrate(s); }
function hydrate(s){ return {...s,tasks:getDb().prepare('SELECT * FROM tasks WHERE session_id=? ORDER BY rowid DESC').all(s.id)}; }
function updateSession(id,status){getDb().prepare('UPDATE sessions SET status=?,updated_at=? WHERE id=?').run(status,now(),id);}
function deleteSession(id){return getDb().prepare('DELETE FROM sessions WHERE id=?').run(id);}
function createTask(t){getDb().prepare('INSERT INTO tasks (id,session_id,prompt,agent,status) VALUES (@id,@session_id,@prompt,@agent,\'queued\')').run(t);return getTask(t.id);}
function getTask(id){const task=getDb().prepare('SELECT * FROM tasks WHERE id=?').get(id);if(!task)return null;return {...task,logs:getDb().prepare('SELECT * FROM logs WHERE task_id=? ORDER BY id').all(id)};}
function updateTask(id, data){const keys=Object.keys(data);if(!keys.length)return;getDb().prepare(`UPDATE tasks SET ${keys.map(k=>`${k}=@${k}`).join(',')} WHERE id=@id`).run({id,...data});}
function addLog(task_id,stream,message){const row={task_id,stream,message,created_at:now()};getDb().prepare('INSERT INTO logs (task_id,stream,message,created_at) VALUES (@task_id,@stream,@message,@created_at)').run(row);return {...row,id:getDb().prepare('SELECT last_insert_rowid() AS id').get().id};}
module.exports={initDb,createSession,listSessions,getSession,updateSession,deleteSession,createTask,getTask,updateTask,addLog};
