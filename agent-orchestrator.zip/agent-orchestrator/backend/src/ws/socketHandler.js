const db=require('../db/models');
function attachSocket(io){io.on('connection',socket=>{socket.emit('sessions:snapshot',db.listSessions());socket.on('session:watch',id=>{for(const room of socket.rooms)if(room.startsWith('session:'))socket.leave(room);if(id)socket.join(`session:${id}`);});});}
module.exports={attachSocket};
