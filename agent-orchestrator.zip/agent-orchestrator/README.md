# Agent Orchestrator

A local dashboard for assigning the same coding task to multiple agent CLIs (Claude, Codex, Gemini), watching their output in real time, and comparing the resulting Git diffs. Each agent receives its own Git worktree.

## Features
- REST API for sessions and tasks
- Socket.IO stream for session/task logs and state transitions
- SQLite persistence (no external database required)
- Isolated Git worktree per agent task
- CLI runner with safe executable allow-list and clean process shutdown
- React/Vite dashboard with live agent cards and diff comparison

## Prerequisites
- Node.js 20+
- Git
- At least one installed/configured optional agent CLI: `claude`, `codex`, or `gemini`
- A **Git repository** to operate on (use `git init` before starting a task)

## Quick start

### Option A — Local machine (laptop/desktop)
```bash
cp backend/.env.example backend/.env
cd backend && npm install && npm run dev
# separate terminal
cd frontend && npm install && npm run dev
```
Open `http://localhost:5173`. The backend defaults to `http://localhost:4000`.

### Option B — GitHub Codespaces (works from a phone browser)
No local install needed — everything runs in the cloud, in your browser.
1. On the repo page: **Code → Codespaces → Create codespace on main**
2. Wait for setup to finish (auto-installs both `backend` and `frontend` deps)
3. Open two terminals in the Codespace: `cd backend && npm run dev` and `cd frontend && npm run dev`
4. Codespaces will prompt to open the forwarded `5173` port — that's your dashboard

Note: agent CLIs (`claude`, `codex`, `gemini`) still need to be installed/authenticated inside the Codespace to run real tasks. **mock** mode works immediately with no setup.

### Test without an agent CLI
Choose **mock** in the UI. It emits representative output and exits successfully, but does not modify files.

### Agent command configuration
Commands are intentionally configurable because CLI flags change over time. Set templates in `backend/.env`; `{prompt}` is shell-quoted before substitution.
```dotenv
CLAUDE_COMMAND=claude -p {prompt}
CODEX_COMMAND=codex exec {prompt}
GEMINI_COMMAND=gemini {prompt}
```
The process is executed in the agent's worktree, never via `shell: true`. Only the configured executable's first token is allowed.

## API
- `GET /api/health`
- `GET|POST /api/sessions`
- `GET|DELETE /api/sessions/:id`
- `POST /api/sessions/:id/stop`
- `GET|POST /api/sessions/:id/tasks`
- `GET /api/tasks/:id`

A task body requires `prompt` and optional `agents` (e.g. `["claude", "codex"]`).

## Notes
Worktrees live under `backend/worktrees/` by default and are removed when a session is deleted. A task may fail when the selected CLI is not installed or its command is not configured; its logs show the exact reason.

## License
MIT — see [LICENSE](./LICENSE).

## CI
GitHub Actions syntax-checks the backend and builds the frontend on every push/PR (`.github/workflows/ci.yml`).
