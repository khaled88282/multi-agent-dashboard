# Future isolation image. Mount a worktree at /workspace and pass an agent CLI.
FROM node:20-bookworm-slim
RUN apt-get update && apt-get install -y --no-install-recommends git ca-certificates && rm -rf /var/lib/apt/lists/*
WORKDIR /workspace
CMD ["bash"]
