import {useEffect,useRef} from 'react';import {io} from 'socket.io-client';
const URL=import.meta.env.VITE_API_URL||'http://localhost:4000';
export function useSocket(onEvent){const ref=useRef(null);useEffect(()=>{const s=io(URL);ref.current=s;for(const e of ['sessions:snapshot','session:updated','task:updated','task:log'])s.on(e,p=>onEvent(e,p));return()=>{s.close();ref.current=null;};},[onEvent]);function watch(sessionId){ref.current?.emit('session:watch',sessionId);}return {watch};}
